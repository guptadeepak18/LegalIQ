# LegalIQ — India's Legal Health Score Platform

## Overview
AI-powered legal diagnostic platform for Indian businesses. Built for Rest The Case (restthecase.com).

## Architecture
- **Frontend**: React + Vite (`artifacts/legaliq-web`) — serves at `/`
- **Backend**: Express API (`artifacts/api-server`) — serves at `/api`
- **Database**: Replit PostgreSQL via Drizzle ORM
- **AI**: Google Gemini 2.0 Flash (question generation + report generation)
- **OTP SMS**: Fast2SMS (`/api/otp/send-phone`)
- **OTP Email**: Resend (`/api/otp/send-email`)
- **WhatsApp alerts**: CallMeBot (admin notifications + user updates)

## Design System: Cinematic Legal — Dual Theme
- **Dark mode** (default): Deep navy gradient `#07091A → #0C1626 → #101C34`, glassmorphic cards `rgba(7,15,40,0.74)`
- **Light mode**: Warm parchment gradient `#F5F0E8 → #EDE5D0 → #E5DEC8`, cream glass cards `rgba(255,252,244,0.76)`
- Gold accent: `#C9A84C` (both themes)
- Fonts: Playfair Display (serif headings) + Inter (body) + Space Grotesk (numbers)
- Theme toggle: sun/moon button stored in `localStorage`, `.dark` class on `<html>`
- HD legal-themed Unsplash backgrounds per page (courthouse, legal signing, law library, scales, office, gavel)
- CSS utilities: `.glass-card`, `.liq-nav`, `.theme-toggle`, `.page-bg-wrap`, `.text-gold-gradient`, `.gold-glow`, `.liq-input`, `.otp-slot`
- Theme components: `ThemeProvider.tsx`, `ThemeToggle.tsx`, `PageBackground.tsx`

## User Flow
1. **Landing** (`/`) — Hero, pillar breakdown, how-it-works, reviews, CTA
2. **Onboard** (`/onboard`) — Phone OTP → Email OTP → Business profile (3 steps)
3. **Assess** (`/assess`) — Two-phase per pillar: 2 fixed seed Qs + 2–4 adaptive Qs (Gemini or static fallback)
4. **Results** (`/results`) — LHS score ring, 5-pillar breakdown, insights, action plan, case study
5. **Consult** (`/consult`) — Date/time slot picker, confirmation email
6. **Review** (`/review`) — Star rating, review form, moderation queue

## Admin Panel (`/admin`)
- Login: `admin@restthecase.com` / `LegalIQ@Admin2025`
- Dashboard: stats (total leads, risk breakdown, recent activity)
- Leads: paginated table with search/filter, CSV export
- Lead detail: full assessment, answers, AI report, status management
- Reviews: moderation queue (approve/reject)

## Scoring Engine (5 Pillars × 20pts = 100)
- Litigation Health, Contractual Health, Compliance Health, Legal Cost Efficiency, Future Risk Exposure
- Raw scores normalised to 20 per pillar regardless of question count
- Risk levels: CRITICAL (≤40), MODERATE (41-70), HEALTHY (71-100)

## Key Files
- `lib/api-spec/openapi.yaml` — Complete OpenAPI spec (18 endpoints)
- `lib/db/src/schema/index.ts` — All 8 DB tables
- `artifacts/api-server/src/services/gemini.ts` — Gemini AI service
- `artifacts/api-server/src/services/scoring.ts` — Pillar scoring engine
- `artifacts/api-server/src/routes/` — All route handlers
- `artifacts/legaliq-web/src/pages/` — All frontend pages
- `artifacts/legaliq-web/src/store/useStore.ts` — Zustand wizard state
- `scripts/src/seed-admin.ts` — Admin user seed script

## Environment Variables Required
| Variable | Source | Purpose |
|---|---|---|
| `DATABASE_URL` | Replit DB | PostgreSQL connection |
| `GEMINI_API_KEY` | aistudio.google.com | AI question/report generation |
| `RESEND_API_KEY` | resend.com | OTP emails + report delivery |
| `FAST2SMS_API_KEY` | fast2sms.com | SMS OTP |
| `CALLMEBOT_API_KEY` | callmebot.com | WhatsApp notifications |
| `ADMIN_WHATSAPP_NUMBER` | Manual | Admin WhatsApp number |
| `JWT_SECRET` | Manual | JWT signing secret |
| `SESSION_SECRET` | Replit Secret | Session encryption |
| `ADMIN_EMAIL` | Manual | Admin email (default: admin@restthecase.com) |
| `ADMIN_PASSWORD` | Manual | Admin password |
| `FROM_EMAIL` | Manual | Sender email for Resend |
| `FRONTEND_URL` | Manual | Frontend base URL for review links |

## Seed Admin
```bash
pnpm --filter @workspace/scripts run seed-admin
```

## DB Schema Push
```bash
pnpm --filter @workspace/db run push
```

## Codegen (OpenAPI → React Query hooks + Zod schemas)
```bash
pnpm --filter @workspace/api-spec run codegen
```

## Dependencies
- `drizzle-orm`, `drizzle-kit` — ORM + migrations
- `bcryptjs` — Password hashing
- `jsonwebtoken` — Admin JWT auth
- `uuid` — Token generation
- `zustand` — Frontend wizard state
- `framer-motion` — Page transitions + score animations
- `wouter` — Lightweight routing
- `sonner` — Toast notifications
- `recharts` — Charts in admin dashboard
