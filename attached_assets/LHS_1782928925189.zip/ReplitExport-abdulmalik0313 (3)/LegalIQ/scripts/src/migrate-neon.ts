import pg from "pg";

const { Pool } = pg;

const connectionString = process.env.NEON_DATABASE_URL ?? process.env.DATABASE_URL;
if (!connectionString) throw new Error("No database URL found");

const pool = new Pool({
  connectionString,
  ssl: connectionString.includes("neon.tech") ? { rejectUnauthorized: false } : undefined,
});

async function run() {
  const client = await pool.connect();
  try {
    console.log("Running Neon DB migrations...");

    await client.query(`
      CREATE TABLE IF NOT EXISTS otp_verifications (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        recipient TEXT NOT NULL,
        type TEXT NOT NULL,
        otp_hash TEXT NOT NULL,
        attempts INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 5,
        expires_at TIMESTAMP NOT NULL,
        verified_at TIMESTAMP,
        verification_token TEXT,
        send_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log("✓ otp_verifications table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS leads (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        company TEXT NOT NULL,
        city TEXT NOT NULL,
        category TEXT NOT NULL,
        sub_category TEXT NOT NULL DEFAULT '',
        business_type TEXT NOT NULL DEFAULT '',
        phone_token TEXT,
        email_token TEXT,
        whatsapp_opt_in BOOLEAN DEFAULT false,
        employee_count TEXT,
        business_age TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS sub_category TEXT NOT NULL DEFAULT '';`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS business_type TEXT NOT NULL DEFAULT '';`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS phone_token TEXT;`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS email_token TEXT;`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS whatsapp_opt_in BOOLEAN DEFAULT false;`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS employee_count TEXT;`);
    await client.query(`ALTER TABLE leads ADD COLUMN IF NOT EXISTS business_age TEXT;`);
    console.log("✓ leads table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
        business_type TEXT,
        registration TEXT,
        employee_count TEXT,
        industry TEXT,
        state TEXT,
        score INTEGER,
        score_breakdown_json JSONB,
        report_json JSONB,
        status TEXT DEFAULT 'in_progress',
        created_at TIMESTAMP DEFAULT NOW(),
        completed_at TIMESTAMP
      );
    `);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS business_type TEXT;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS registration TEXT;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS employee_count TEXT;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS industry TEXT;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS state TEXT;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS score INTEGER;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS score_breakdown_json JSONB;`);
    await client.query(`ALTER TABLE sessions ADD COLUMN IF NOT EXISTS report_json JSONB;`);
    console.log("✓ sessions table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS assessments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
        total_score INTEGER DEFAULT 0,
        risk_level TEXT DEFAULT 'MODERATE',
        litigation_score INTEGER DEFAULT 0,
        contractual_score INTEGER DEFAULT 0,
        compliance_score INTEGER DEFAULT 0,
        cost_score INTEGER DEFAULT 0,
        future_score INTEGER DEFAULT 0,
        status TEXT DEFAULT 'new',
        completed_at TIMESTAMP DEFAULT NOW()
      );
    `);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS total_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS risk_level TEXT DEFAULT 'MODERATE';`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS litigation_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS contractual_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS compliance_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS cost_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS future_score INTEGER DEFAULT 0;`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'new';`);
    await client.query(`ALTER TABLE assessments ADD COLUMN IF NOT EXISTS completed_at TIMESTAMP DEFAULT NOW();`);
    console.log("✓ assessments table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS answers (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        assessment_id UUID REFERENCES assessments(id) ON DELETE CASCADE,
        question TEXT NOT NULL,
        pillar TEXT NOT NULL,
        answer TEXT NOT NULL,
        score INTEGER DEFAULT 0,
        is_seed BOOLEAN DEFAULT false,
        is_reverse_scored BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log("✓ answers table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS reports (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        assessment_id UUID REFERENCES assessments(id) ON DELETE CASCADE,
        summary TEXT,
        pillar_assessments JSONB DEFAULT '{}',
        insights JSONB DEFAULT '[]',
        actions JSONB DEFAULT '[]',
        example JSONB DEFAULT '{}',
        vclo_pitch TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    await client.query(`ALTER TABLE reports ADD COLUMN IF NOT EXISTS future_risk_outlook TEXT;`);
    console.log("✓ reports table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS consultations (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
        date TEXT,
        time TEXT,
        notes TEXT,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log("✓ consultations table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS reviews (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        lead_id UUID,
        reviewer_name TEXT NOT NULL,
        company TEXT NOT NULL,
        business_type TEXT,
        city TEXT,
        rating INTEGER NOT NULL,
        headline TEXT NOT NULL,
        body TEXT NOT NULL,
        lhs_score INTEGER,
        risk_level TEXT,
        verified_user BOOLEAN DEFAULT false,
        status TEXT DEFAULT 'PENDING',
        rejection_note TEXT,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS lead_id UUID;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS reviewer_name TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS company TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS business_type TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS city TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS rating INTEGER;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS headline TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS body TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS lhs_score INTEGER;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS risk_level TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS verified_user BOOLEAN DEFAULT false;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'PENDING';`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS rejection_note TEXT;`);
    await client.query(`ALTER TABLE reviews ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT NOW();`);
    console.log("✓ reviews table ready");

    await client.query(`
      CREATE TABLE IF NOT EXISTS admin_users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);
    console.log("✓ admin_users table ready");

    console.log("\n✅ All migrations complete!");
  } catch (err) {
    console.error("Migration error:", err);
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch((err) => { console.error(err); process.exit(1); });
