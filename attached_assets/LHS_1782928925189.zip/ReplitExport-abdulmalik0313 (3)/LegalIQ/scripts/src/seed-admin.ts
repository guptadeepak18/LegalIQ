import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import bcrypt from "bcryptjs";

const { Pool } = pg;

async function seedAdmin() {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    throw new Error("DATABASE_URL is not set");
  }

  const email = process.env.ADMIN_EMAIL ?? "admin@restthecase.com";
  const password = process.env.ADMIN_PASSWORD ?? "LegalIQ@Admin2025";

  const pool = new Pool({ connectionString: dbUrl });

  try {
    const existing = await pool.query(
      "SELECT id FROM admin_users WHERE email = $1",
      [email]
    );

    if (existing.rows.length > 0) {
      console.log(`Admin user already exists: ${email}`);
      return;
    }

    const passwordHash = await bcrypt.hash(password, 12);
    await pool.query(
      "INSERT INTO admin_users (email, password_hash) VALUES ($1, $2)",
      [email, passwordHash]
    );

    console.log(`✅ Admin user created: ${email}`);
    console.log(`   Password: ${password}`);
    console.log(`   (Change this password after first login!)`);
  } finally {
    await pool.end();
  }
}

seedAdmin().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
