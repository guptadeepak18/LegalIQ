import pg from "pg";

const { Pool } = pg;
const connectionString = process.env.NEON_DATABASE_URL ?? process.env.DATABASE_URL;
if (!connectionString) throw new Error("No database URL found");

const pool = new Pool({
  connectionString,
  ssl: connectionString.includes("neon.tech") ? { rejectUnauthorized: false } : undefined,
});

async function safeRename(client: pg.PoolClient, table: string, oldCol: string, newCol: string) {
  const check = await client.query(
    `SELECT column_name FROM information_schema.columns WHERE table_name=$1 AND column_name=$2`,
    [table, oldCol]
  );
  const hasNew = await client.query(
    `SELECT column_name FROM information_schema.columns WHERE table_name=$1 AND column_name=$2`,
    [table, newCol]
  );
  if (check.rows.length > 0 && hasNew.rows.length === 0) {
    await client.query(`ALTER TABLE "${table}" RENAME COLUMN "${oldCol}" TO "${newCol}"`);
    console.log(`  ✓ renamed ${oldCol} → ${newCol}`);
  } else if (hasNew.rows.length > 0) {
    console.log(`  ⟳ ${newCol} already exists, skipping rename`);
  } else {
    console.log(`  ⚠ ${oldCol} not found in ${table}`);
  }
}

async function safeAdd(client: pg.PoolClient, table: string, col: string, definition: string) {
  await client.query(`ALTER TABLE "${table}" ADD COLUMN IF NOT EXISTS "${col}" ${definition}`);
  console.log(`  ✓ ensured ${col}`);
}

async function run() {
  const client = await pool.connect();
  try {
    // ── 1. otp_verifications — incompatible (integer id, wrong columns) ────────
    console.log("\n[1] Rebuilding otp_verifications...");
    await client.query(`DROP TABLE IF EXISTS otp_verifications CASCADE`);
    await client.query(`
      CREATE TABLE otp_verifications (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        recipient TEXT NOT NULL,
        type TEXT NOT NULL,
        otp_hash TEXT NOT NULL,
        attempts INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 5,
        expires_at TIMESTAMP NOT NULL,
        verified_at TIMESTAMP,
        verification_token TEXT,
        send_count INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT NOW()
      )
    `);
    console.log("  ✓ otp_verifications rebuilt with correct schema");

    // ── 2. leads — rename mismatched columns ───────────────────────────────────
    console.log("\n[2] Fixing leads...");
    await safeRename(client, "leads", "company_name", "company");
    await safeRename(client, "leads", "business_category", "category");
    await safeAdd(client, "leads", "company", "TEXT NOT NULL DEFAULT ''");
    await safeAdd(client, "leads", "category", "TEXT NOT NULL DEFAULT ''");
    await safeAdd(client, "leads", "sub_category", "TEXT NOT NULL DEFAULT ''");
    await safeAdd(client, "leads", "business_type", "TEXT NOT NULL DEFAULT ''");
    await safeAdd(client, "leads", "review_token", "TEXT");
    await safeAdd(client, "leads", "business_age", "TEXT");
    await safeAdd(client, "leads", "employee_count", "TEXT");

    // ── 3. assessments — add missing pillar score columns ──────────────────────
    console.log("\n[3] Fixing assessments...");
    await safeAdd(client, "assessments", "total_score", "INTEGER DEFAULT 0");
    await safeAdd(client, "assessments", "litigation_score", "INTEGER DEFAULT 0");
    await safeAdd(client, "assessments", "contractual_score", "INTEGER DEFAULT 0");
    await safeAdd(client, "assessments", "compliance_score", "INTEGER DEFAULT 0");
    await safeAdd(client, "assessments", "cost_score", "INTEGER DEFAULT 0");

    // ── 4. answers — rename mismatched columns, add missing ───────────────────
    console.log("\n[4] Fixing answers...");
    await safeRename(client, "answers", "question_text", "question");
    await safeRename(client, "answers", "score_impact", "score");
    await safeAdd(client, "answers", "question", "TEXT NOT NULL DEFAULT ''");
    await safeAdd(client, "answers", "score", "INTEGER DEFAULT 0");
    await safeAdd(client, "answers", "is_seed", "BOOLEAN DEFAULT false");
    await safeAdd(client, "answers", "is_reverse_scored", "BOOLEAN DEFAULT false");

    // ── 5. reports — add missing columns (keep report_data for compat) ─────────
    console.log("\n[5] Fixing reports...");
    await safeAdd(client, "reports", "summary", "TEXT");
    await safeAdd(client, "reports", "pillar_assessments", "JSONB DEFAULT '{}'");
    await safeAdd(client, "reports", "insights", "JSONB DEFAULT '[]'");
    await safeAdd(client, "reports", "actions", "JSONB DEFAULT '[]'");
    await safeAdd(client, "reports", "example", "JSONB DEFAULT '{}'");
    await safeAdd(client, "reports", "vclo_pitch", "TEXT");
    await safeAdd(client, "reports", "future_risk_outlook", "TEXT");
    await safeAdd(client, "reports", "created_at", "TIMESTAMP DEFAULT NOW()");

    // ── 6. consultations — add missing date/time columns ──────────────────────
    console.log("\n[6] Fixing consultations...");
    await safeAdd(client, "consultations", "date", "TEXT");
    await safeAdd(client, "consultations", "time", "TEXT");

    // ── 7. reviews — ensure all columns present (already done in migrate-neon) ─
    console.log("\n[7] Verifying reviews...");
    await safeAdd(client, "reviews", "reviewer_name", "TEXT");
    await safeAdd(client, "reviews", "company", "TEXT");
    await safeAdd(client, "reviews", "headline", "TEXT");
    await safeAdd(client, "reviews", "body", "TEXT");
    await safeAdd(client, "reviews", "lhs_score", "INTEGER");
    await safeAdd(client, "reviews", "risk_level", "TEXT");
    await safeAdd(client, "reviews", "verified_user", "BOOLEAN DEFAULT false");
    await safeAdd(client, "reviews", "rejection_note", "TEXT");

    console.log("\n✅ All schema fixes applied!");
  } catch (err) {
    console.error("Fix error:", err);
    throw err;
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch((err) => { console.error(err); process.exit(1); });
