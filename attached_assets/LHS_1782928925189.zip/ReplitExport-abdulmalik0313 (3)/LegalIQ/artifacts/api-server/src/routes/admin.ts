import { Router } from "express";
import { db } from "@workspace/db";
import {
  leads,
  assessments,
  reports,
  answers as answersTable,
  reviews,
  consultations,
} from "@workspace/db";
import { eq, desc, gte, lt, and, count, avg } from "drizzle-orm";
import { requireAuth } from "../middleware/auth.js";
import { logger } from "../lib/logger.js";

const router = Router();

// ── Gemini helper (admin-only, isolated quota) ────────────────────────────────
const GEMINI_API_KEY = process.env.GEMINI_API_KEY ?? "";
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const ADMIN_GEMINI_MODELS = ["gemini-2.0-flash", "gemini-2.0-flash-lite", "gemini-2.5-flash-lite"];

async function callGeminiAdmin(prompt: string, maxTokens = 1200): Promise<string> {
  for (const model of ADMIN_GEMINI_MODELS) {
    const url = `${GEMINI_BASE}/${model}:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.7, maxOutputTokens: maxTokens },
      }),
    });
    if (response.status === 429) { logger.warn({ model }, "Admin Gemini 429, trying next"); continue; }
    if (!response.ok) throw new Error(`Gemini ${response.status}`);
    const data = await response.json() as { candidates?: Array<{ content: { parts: Array<{ text: string }> } }> };
    return data.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  }
  throw new Error("RATE_LIMITED");
}

function extractJSON(raw: string): Record<string, unknown> {
  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) return {};
  try { return JSON.parse(match[0]); } catch { return {}; }
}

// ── GET /admin/stats ─────────────────────────────────────────────────────────
router.get("/admin/stats", requireAuth, async (_req, res) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const [
    [totalLeadsResult],
    [assessmentsResult],
    [consultationsResult],
    [todayResult],
    [weekResult],
    [avgResult],
    [d0_40],
    [d40_60],
    [d60_80],
    [d80],
    riskBreakdown,
    recentLeads,
    allReportsInsights,
  ] = await Promise.all([
    db.select({ count: count() }).from(leads),
    db.select({ count: count() }).from(assessments),
    db.select({ count: count() }).from(consultations),
    db.select({ count: count() }).from(assessments).where(gte(assessments.completedAt, today)),
    db.select({ count: count() }).from(assessments).where(gte(assessments.completedAt, weekAgo)),
    db.select({ avg: avg(assessments.totalScore) }).from(assessments),
    db.select({ count: count() }).from(assessments).where(lt(assessments.totalScore, 40)),
    db.select({ count: count() }).from(assessments).where(and(gte(assessments.totalScore, 40), lt(assessments.totalScore, 60))),
    db.select({ count: count() }).from(assessments).where(and(gte(assessments.totalScore, 60), lt(assessments.totalScore, 80))),
    db.select({ count: count() }).from(assessments).where(gte(assessments.totalScore, 80)),
    db.select({ riskLevel: assessments.riskLevel, count: count() }).from(assessments).groupBy(assessments.riskLevel),
    db.select({
      id: leads.id, name: leads.name, company: leads.company, businessType: leads.businessType,
      city: leads.city, createdAt: leads.createdAt, totalScore: assessments.totalScore,
      riskLevel: assessments.riskLevel, status: assessments.status,
    }).from(leads).leftJoin(assessments, eq(leads.id, assessments.leadId)).orderBy(desc(leads.createdAt)).limit(5),
    db.select({ insights: reports.insights }).from(reports),
  ]);

  const riskBreakdownMap: Record<string, number> = {};
  for (const r of riskBreakdown) {
    if (r.riskLevel) riskBreakdownMap[r.riskLevel] = r.count;
  }

  const flagCounts: Record<string, number> = {};
  for (const r of allReportsInsights) {
    const ins = (r.insights as Array<{ title: string }> | null) ?? [];
    for (const insight of ins) {
      if (insight.title) flagCounts[insight.title] = (flagCounts[insight.title] ?? 0) + 1;
    }
  }
  const topRiskFlags = Object.entries(flagCounts)
    .sort((a, b) => b[1] - a[1]).slice(0, 3)
    .map(([title, flagCount]) => ({ title, count: flagCount }));

  res.json({
    success: true,
    totalLeads: totalLeadsResult.count,
    assessmentsComplete: assessmentsResult.count,
    consultationsBooked: consultationsResult.count,
    todayCount: todayResult.count,
    weekCount: weekResult.count,
    avgScore: Math.round(Number(avgResult?.avg ?? 0)),
    scoreDistribution: { critical: d0_40.count, moderate: d40_60.count, healthy: d60_80.count, excellent: d80.count },
    criticalRisk: riskBreakdownMap["CRITICAL"] ?? 0,
    moderateRisk: riskBreakdownMap["MODERATE"] ?? 0,
    legallyHealthy: riskBreakdownMap["HEALTHY"] ?? 0,
    riskBreakdown: riskBreakdownMap,
    topRiskFlags,
    recentLeads,
  });
});

// ── GET /admin/analytics ─────────────────────────────────────────────────────
router.get("/admin/analytics", requireAuth, async (_req, res) => {
  const [byTypeRows, [pillarRow], [totalAssessmentsResult], [totalConsultationsResult]] = await Promise.all([
    db.select({ businessType: leads.businessType, avgScore: avg(assessments.totalScore), count: count() })
      .from(assessments).innerJoin(leads, eq(assessments.leadId, leads.id)).groupBy(leads.businessType),
    db.select({ litigation: avg(assessments.litigationScore), contractual: avg(assessments.contractualScore), compliance: avg(assessments.complianceScore), cost: avg(assessments.costScore), future: avg(assessments.futureScore) }).from(assessments),
    db.select({ count: count() }).from(assessments),
    db.select({ count: count() }).from(consultations),
  ]);

  const avgByBusinessType = byTypeRows.map((r) => ({ businessType: r.businessType, avgScore: Math.round(Number(r.avgScore ?? 0)), count: r.count })).sort((a, b) => b.count - a.count);
  const pillarAverages = { litigation: Math.round(Number(pillarRow?.litigation ?? 0)), contractual: Math.round(Number(pillarRow?.contractual ?? 0)), compliance: Math.round(Number(pillarRow?.compliance ?? 0)), cost: Math.round(Number(pillarRow?.cost ?? 0)), future: Math.round(Number(pillarRow?.future ?? 0)) };
  const conversionRate = totalAssessmentsResult.count > 0 ? Math.round((totalConsultationsResult.count / totalAssessmentsResult.count) * 100) : 0;

  res.json({ success: true, avgByBusinessType, pillarAverages, conversionRate, totalAssessments: totalAssessmentsResult.count, totalConsultations: totalConsultationsResult.count });
});

// ── GET /admin/ai-insights ────────────────────────────────────────────────────
router.get("/admin/ai-insights", requireAuth, async (_req, res) => {
  const [[totalLeads], [totalAssessments], [avgResult], [d0], [d40], [d60], [d80], [pillarRow], byType, allFlags, [totalConsultations]] = await Promise.all([
    db.select({ count: count() }).from(leads),
    db.select({ count: count() }).from(assessments),
    db.select({ avg: avg(assessments.totalScore) }).from(assessments),
    db.select({ count: count() }).from(assessments).where(lt(assessments.totalScore, 40)),
    db.select({ count: count() }).from(assessments).where(and(gte(assessments.totalScore, 40), lt(assessments.totalScore, 60))),
    db.select({ count: count() }).from(assessments).where(and(gte(assessments.totalScore, 60), lt(assessments.totalScore, 80))),
    db.select({ count: count() }).from(assessments).where(gte(assessments.totalScore, 80)),
    db.select({ litigation: avg(assessments.litigationScore), contractual: avg(assessments.contractualScore), compliance: avg(assessments.complianceScore), cost: avg(assessments.costScore), future: avg(assessments.futureScore) }).from(assessments),
    db.select({ businessType: leads.businessType, avgScore: avg(assessments.totalScore), count: count() }).from(assessments).innerJoin(leads, eq(assessments.leadId, leads.id)).groupBy(leads.businessType),
    db.select({ insights: reports.insights }).from(reports),
    db.select({ count: count() }).from(consultations),
  ]);

  const flagCounts: Record<string, number> = {};
  for (const r of allFlags) {
    const ins = (r.insights as Array<{ title: string }> | null) ?? [];
    for (const i of ins) { if (i.title) flagCounts[i.title] = (flagCounts[i.title] ?? 0) + 1; }
  }
  const topFlags = Object.entries(flagCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([title, c]) => ({ title, count: c }));
  const topTypes = byType.sort((a, b) => b.count - a.count).slice(0, 5);
  const total = totalAssessments.count || 1;
  const avgScore = Math.round(Number(avgResult?.avg ?? 0));
  const conversionRate = total > 0 ? Math.round((totalConsultations.count / total) * 100) : 0;
  const pillars = { litigation: Math.round(Number(pillarRow?.litigation ?? 0)), contractual: Math.round(Number(pillarRow?.contractual ?? 0)), compliance: Math.round(Number(pillarRow?.compliance ?? 0)), cost: Math.round(Number(pillarRow?.cost ?? 0)), future: Math.round(Number(pillarRow?.future ?? 0)) };

  const prompt = `You are a senior legal business intelligence analyst at Rest The Case, India's leading VCLO (Virtual Chief Legal Officer) firm.

Analyse this LegalIQ assessment portfolio and return strategic intelligence:

PORTFOLIO METRICS:
- Total leads: ${totalLeads.count}
- Total assessments completed: ${total}
- Average Legal Health Score: ${avgScore}/100
- Conversion rate (assessment → consultation booked): ${conversionRate}%

SCORE DISTRIBUTION:
- Critical risk (0-40): ${d0.count} leads (${Math.round(d0.count/total*100)}%)
- Moderate risk (40-60): ${d40.count} leads (${Math.round(d40.count/total*100)}%)
- Healthy (60-80): ${d60.count} leads (${Math.round(d60.count/total*100)}%)
- Excellent (80-100): ${d80.count} leads (${Math.round(d80.count/total*100)}%)

PILLAR AVERAGES (each out of 25):
- Litigation: ${pillars.litigation}/25
- Contractual: ${pillars.contractual}/25
- Compliance: ${pillars.compliance}/25
- Cost Efficiency: ${pillars.cost}/25

TOP BUSINESS TYPES:
${topTypes.map((b) => `- ${b.businessType}: ${b.count} leads, avg score ${Math.round(Number(b.avgScore ?? 0))}`).join("\n")}

MOST COMMON RISK FLAGS:
${topFlags.map((f, i) => `${i + 1}. ${f.title} (${f.count} occurrences)`).join("\n")}

Return ONLY valid JSON in this exact format:
{
  "executiveSummary": "2-3 sentences: current portfolio health, biggest opportunity, one urgent action",
  "findings": [
    { "title": "...", "detail": "...", "impact": "high", "action": "specific actionable recommendation" },
    { "title": "...", "detail": "...", "impact": "medium", "action": "specific actionable recommendation" },
    { "title": "...", "detail": "...", "impact": "low", "action": "specific actionable recommendation" }
  ],
  "prioritySegment": {
    "description": "which specific business type + score range to focus outreach on right now",
    "reason": "why this segment has highest conversion potential based on the data",
    "estimatedLeads": <number of leads in this segment>
  },
  "contrarian": "one non-obvious insight that most people would miss from this data",
  "weeklyFocus": "one specific action to take this week to improve conversion rate"
}`;

  try {
    const raw = await callGeminiAdmin(prompt, 1500);
    const parsed = extractJSON(raw);
    if (!parsed.executiveSummary) {
      res.json({ success: false, rateLimited: false, error: "Invalid AI response" });
      return;
    }
    res.json({ success: true, ...parsed });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    if (message === "RATE_LIMITED") {
      res.json({ success: true, rateLimited: true });
    } else {
      logger.error({ err }, "AI insights generation failed");
      res.status(500).json({ success: false, message: "AI analysis failed" });
    }
  }
});

// ── POST /admin/leads/:id/draft-email ─────────────────────────────────────────
router.post("/admin/leads/:id/draft-email", requireAuth, async (req, res) => {
  const { id } = req.params;

  const [lead] = await db.select().from(leads).where(eq(leads.id, String(id)));
  if (!lead) { res.status(404).json({ success: false, message: "Lead not found" }); return; }

  const [assessment] = await db.select().from(assessments).where(eq(assessments.leadId, String(id)));
  if (!assessment) { res.status(400).json({ success: false, message: "No assessment found" }); return; }

  let topRisk = "legal compliance gaps";
  const [report] = await db.select({ insights: reports.insights }).from(reports).where(eq(reports.assessmentId, assessment.id));
  if (report?.insights) {
    const ins = report.insights as Array<{ title: string; severity: string }>;
    const highIns = ins.find((i) => i.severity === "HIGH") ?? ins[0];
    if (highIns) topRisk = highIns.title;
  }

  const PILLAR_LABELS: Record<string, string> = { litigationScore: "Litigation", contractualScore: "Contractual", complianceScore: "Compliance", costScore: "Cost Efficiency" };
  const pillarEntries = Object.entries(PILLAR_LABELS).map(([key, label]) => ({ label, score: (assessment as Record<string, unknown>)[key] as number }));
  const weakest = pillarEntries.sort((a, b) => a.score - b.score)[0];

  const prompt = `You are an outreach specialist at Rest The Case, a VCLO (Virtual Chief Legal Officer) firm in India helping businesses with proactive legal protection.

Write a personalised, professional follow-up email for this lead:
Name: ${lead.name}
Company: ${lead.company}
Business Type: ${lead.businessType}
City: ${lead.city}

Their LegalIQ Assessment Results:
- Legal Health Score: ${assessment.totalScore}/100 (${assessment.riskLevel} risk)
- Weakest area: ${weakest?.label ?? "Compliance"} (${weakest?.score ?? 0}/20)
- Top risk identified: "${topRisk}"

Write a 3-paragraph follow-up email:
1. Open by acknowledging their specific score and key vulnerability (use their actual data)
2. Explain precisely how a VCLO addresses their ${weakest?.label ?? "compliance"} weakness — give one concrete example
3. Clear, warm CTA to book a free 15-minute legal health consultation

Tone: Professional, empathetic, India-aware business context. NOT generic.
Length: Under 200 words.

Return ONLY valid JSON:
{ "subject": "...", "body": "..." }`;

  try {
    const raw = await callGeminiAdmin(prompt, 600);
    const parsed = extractJSON(raw) as { subject?: string; body?: string };
    if (!parsed.subject || !parsed.body) {
      res.json({ success: false, rateLimited: false, error: "Invalid AI response" });
      return;
    }
    res.json({ success: true, subject: parsed.subject, body: parsed.body });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    if (message === "RATE_LIMITED") {
      res.json({ success: true, rateLimited: true });
    } else {
      res.status(500).json({ success: false, message: "Email draft failed" });
    }
  }
});

// ── GET /admin/leads ─────────────────────────────────────────────────────────
router.get("/admin/leads", requireAuth, async (req, res) => {
  const page = Number(req.query.page ?? 1);
  const limit = Number(req.query.limit ?? 20);
  const search = req.query.search as string | undefined;
  const risk = req.query.risk as string | undefined;
  const status = req.query.status as string | undefined;
  const businessTypeFilter = req.query.businessType as string | undefined;
  const scoreMin = req.query.scoreMin !== undefined ? Number(req.query.scoreMin) : undefined;
  const scoreMax = req.query.scoreMax !== undefined ? Number(req.query.scoreMax) : undefined;
  const dateFrom = req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined;
  const offset = (page - 1) * limit;

  const allLeads = await db.select({
    id: leads.id, name: leads.name, company: leads.company, businessType: leads.businessType,
    city: leads.city, email: leads.email, phone: leads.phone, createdAt: leads.createdAt,
    totalScore: assessments.totalScore, riskLevel: assessments.riskLevel, status: assessments.status,
  }).from(leads).leftJoin(assessments, eq(leads.id, assessments.leadId)).orderBy(desc(leads.createdAt)).limit(limit).offset(offset);

  let filtered = allLeads;
  if (search) { const s = search.toLowerCase(); filtered = filtered.filter((l) => l.name.toLowerCase().includes(s) || l.company.toLowerCase().includes(s) || l.email?.toLowerCase().includes(s)); }
  if (risk) filtered = filtered.filter((l) => l.riskLevel === risk);
  if (status) filtered = filtered.filter((l) => l.status === status);
  if (businessTypeFilter) filtered = filtered.filter((l) => l.businessType === businessTypeFilter);
  if (scoreMin !== undefined) filtered = filtered.filter((l) => (l.totalScore ?? 0) >= scoreMin);
  if (scoreMax !== undefined) filtered = filtered.filter((l) => (l.totalScore ?? 0) <= scoreMax);
  if (dateFrom) filtered = filtered.filter((l) => l.createdAt && new Date(l.createdAt) >= dateFrom);

  const [totalResult] = await db.select({ count: count() }).from(leads);
  const businessTypes = await db.selectDistinct({ businessType: leads.businessType }).from(leads).orderBy(leads.businessType);

  res.json({ success: true, leads: filtered, total: totalResult.count, page, totalPages: Math.ceil(totalResult.count / limit), businessTypes: businessTypes.map((b) => b.businessType) });
});

// ── GET /admin/leads/:id ─────────────────────────────────────────────────────
router.get("/admin/leads/:id", requireAuth, async (req, res) => {
  const { id } = req.params;
  const [lead] = await db.select().from(leads).where(eq(leads.id, String(id)));
  if (!lead) { res.status(404).json({ success: false, message: "Lead not found" }); return; }

  const [assessment] = await db.select().from(assessments).where(eq(assessments.leadId, String(id)));
  let report = null;
  let answersList: typeof answersTable.$inferSelect[] = [];

  if (assessment) {
    const [r] = await db.select().from(reports).where(eq(reports.assessmentId, assessment.id));
    report = r ?? null;
    answersList = await db.select().from(answersTable).where(eq(answersTable.assessmentId, assessment.id));
  }

  res.json({
    success: true,
    lead: {
      ...lead,
      assessment: assessment ? {
        ...assessment,
        report: report ? { summary: report.summary, pillarAssessments: report.pillarAssessments, insights: report.insights, actions: report.actions, example: report.example, vcloPitch: report.vcloPitch } : null,
        answers: answersList.map((a) => ({ question: a.question, pillar: a.pillar, answer: a.answer, score: a.score })),
      } : null,
    },
  });
});

// ── PATCH /admin/leads/:id/status ────────────────────────────────────────────
router.patch("/admin/leads/:id/status", requireAuth, async (req, res) => {
  const { id } = req.params;
  const { status } = req.body as { status: string };
  if (!status) { res.status(400).json({ success: false, message: "Status required" }); return; }
  await db.update(assessments).set({ status }).where(eq(assessments.leadId, String(id)));
  res.json({ success: true, message: "Status updated" });
});

// ── GET /admin/export ─────────────────────────────────────────────────────────
router.get("/admin/export", requireAuth, async (_req, res) => {
  const allLeads = await db.select({
    id: leads.id, name: leads.name, email: leads.email, phone: leads.phone, company: leads.company,
    city: leads.city, category: leads.category, businessType: leads.businessType, createdAt: leads.createdAt,
    totalScore: assessments.totalScore, riskLevel: assessments.riskLevel, status: assessments.status,
    litigationScore: assessments.litigationScore, contractualScore: assessments.contractualScore,
    complianceScore: assessments.complianceScore, costScore: assessments.costScore, futureScore: assessments.futureScore,
  }).from(leads).leftJoin(assessments, eq(leads.id, assessments.leadId)).orderBy(desc(leads.createdAt));

  const headers = ["ID","Name","Email","Phone","Company","City","Category","Business Type","Score","Risk Level","Status","Litigation","Contractual","Compliance","Cost","Future","Created At"];
  const rows = allLeads.map((l) =>
    [l.id,l.name,l.email,l.phone,l.company,l.city,l.category,l.businessType,l.totalScore??"",l.riskLevel??"",l.status??"",l.litigationScore??"",l.contractualScore??"",l.complianceScore??"",l.costScore??"",l.futureScore??"",l.createdAt?.toISOString()??""]
      .map((v) => `"${String(v).replace(/"/g,'""')}"`)
      .join(",")
  );
  const csv = [headers.join(","), ...rows].join("\n");
  res.setHeader("Content-Type","text/csv");
  res.setHeader("Content-Disposition",`attachment; filename="legaliq-leads-${Date.now()}.csv"`);
  res.send(csv);
});

// ── GET /admin/reviews ────────────────────────────────────────────────────────
router.get("/admin/reviews", requireAuth, async (_req, res) => {
  const allReviews = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  res.json({ success: true, reviews: allReviews, pendingCount: allReviews.filter((r) => r.status === "PENDING").length });
});

// ── PATCH /admin/reviews/:id ──────────────────────────────────────────────────
router.patch("/admin/reviews/:id", requireAuth, async (req, res) => {
  const { id } = req.params;
  const { action, rejectionNote } = req.body as { action: "APPROVE" | "REJECT"; rejectionNote?: string };
  const status = action === "APPROVE" ? "APPROVED" : "REJECTED";
  await db.update(reviews).set({ status, rejectionNote }).where(eq(reviews.id, String(id)));
  res.json({ success: true, message: `Review ${status.toLowerCase()}` });
});

export default router;
