import pg from "pg";

const { Pool } = pg;
const connectionString = process.env.NEON_DATABASE_URL ?? process.env.DATABASE_URL;
if (!connectionString) throw new Error("No database URL found");

const pool = new Pool({
  connectionString,
  ssl: connectionString.includes("neon.tech") ? { rejectUnauthorized: false } : undefined,
});

async function run() {
  const client = await pool.connect();
  try {
    const tables = ["otp_verifications", "leads", "sessions", "assessments", "answers", "reports", "reviews", "admin_users", "consultations"];
    for (const table of tables) {
      const res = await client.query(
        `SELECT column_name, data_type, is_nullable, column_default
         FROM information_schema.columns
         WHERE table_name = $1 ORDER BY ordinal_position`,
        [table]
      );
      if (res.rows.length === 0) {
        console.log(`\n${table}: DOES NOT EXIST`);
      } else {
        console.log(`\n${table}:`);
        res.rows.forEach((r) => {
          console.log(`  ${r.column_name} (${r.data_type}, nullable=${r.is_nullable})`);
        });
      }
    }
  } finally {
    client.release();
    await pool.end();
  }
}

run().catch((err) => { console.error(err); process.exit(1); });
